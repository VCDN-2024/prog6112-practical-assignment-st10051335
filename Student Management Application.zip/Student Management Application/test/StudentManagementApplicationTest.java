
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import student.management.application.Student;


public class StudentManagementApplicationTest {

public class StudentManagerApplicationTest {
    private StudentManagerApplication studentManager;

    @Before
    public void setUp() {
        studentManager = new StudentManagerApplication();
    }

    @Test
    public void testSaveStudent() {
        studentManager.saveStudent("S001", "Student1", 10);
        assertStudentDetails("S001", "Student1", 10, studentManager.getStudents().get(0));
    }

    @Test
    public void testSearchStudent() {
        studentManager.saveStudent("S001", "Student1", 10);
        Student foundStudent = studentManager.searchStudent("S001");
        assertStudentDetails("S001", "Student1", 10, foundStudent);
    }

    @Test
    public void testSearchStudentNotFound() {
        Student foundStudent = studentManager.searchStudent("S999");
        assertNull(foundStudent);
    }

    /**
     *
     */
    @Test
    public void testDeleteStudent() {
        studentManager.saveStudent("S001", "Student1", 10);
        studentManager.deleteStudent("S001");
        assertNull(studentManager.searchStudent("S001"));
    }

    @Test
    public void testDeleteStudentNotFound() {
        studentManager.deleteStudent("S999");
        assertTrue(true);
    }

    private void assertStudentDetails(String expectedId, String expectedName, int expectedAge, Student student) {
        assertEquals(expectedId, student.getStudentId());
        assertEquals(expectedName, student.getStudentName());
        assertEquals(expectedAge, student.getStudentAge());
    }
}
}


