//code attributions Prog6112 repo link. Assignment support @https://github.com/VCDN-2024/PROG6112-REPO/tree/main/PROG6112%20ASSIGNMENT%20SUPPORT/Product
package student.management.application;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class StudentManagementApplication {

    private final ArrayList<Student> students;
    private final Scanner scanner; 

    public StudentManagementApplication() {
        students = new ArrayList<>(); 
        scanner = new Scanner(System.in); 
    }
  
    public void saveStudent() {
        scanner.nextLine(); 
        System.out.print("Enter Student ID: ");
        String studentId = scanner.nextLine();
        System.out.print("Enter Student Name: ");
        String studentName = scanner.nextLine();

        int studentQuantity = 0;
        boolean validInput = false;

        while (!validInput) {
            System.out.print("Enter Student Age (minimum 10): ");
            try {
                studentQuantity = scanner.nextInt();
                if (studentQuantity < 10) {
                    System.out.println("Student Age must be at least 10. Please re-enter.");
                } else {
                    validInput = true;
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a numeric value for Age.");
                scanner.next(); 
            }
        }

        Student newStudent = new Student(studentId, studentName, studentQuantity);
        students.add(newStudent);
        System.out.println("Student saved successfully.");
    }
    
    public void saveStudent(String studentId, String studentName, int studentQuantity) {
        Student newStudent = new Student(studentId, studentName, studentQuantity);
        students.add(newStudent);
        System.out.println("Student saved successfully.");
    }

    public Student searchStudent(String studentId) {
        for (Student student : students) {
            if (student.getStudentId().equalsIgnoreCase(studentId)) {
                return student;  
            }
        }
        return null; 
    }

    public void deleteStudent() {
        scanner.nextLine(); 
        System.out.print("Enter Student ID to delete: ");
        String studentId = scanner.nextLine();
        boolean found = false;

        for (Student student : students) {
            if (student.getStudentId().equalsIgnoreCase(studentId)) {
                System.out.print("Are you sure you want to delete this student? (y/n): ");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("y")) {
                    students.remove(student);
                    System.out.println("Student deleted successfully.");
                } else {
                    System.out.println("Deletion canceled.");
                }
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student not found.");
        }
    }

    public void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
        } else {
            System.out.println("\nStudent Report:");
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }

    public void exitApplication() {
        System.out.println("Exiting application. Goodbye!");
    }

    public ArrayList<Student> getStudents() {
        return students;
    }

    public void launchMenu() {
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Capture a new student");
            System.out.println("2. Search for a student");
            System.out.println("3. Delete a student");
            System.out.println("4. Print student report");
            System.out.println("5. Exit application");
            System.out.print("Enter your choice: ");
            
            int choice;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Exiting application.");
                break;
            }

            switch (choice) {
                case 1:
                    saveStudent(); 
                    break;
                case 2:
                    scanner.nextLine(); 
                    System.out.print("Enter Student ID to search: ");
                    String searchId = scanner.nextLine();
                    Student foundStudent = searchStudent(searchId);
                    if (foundStudent != null) {
                        System.out.println("Student found: " + foundStudent);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;
                case 3:
                    deleteStudent(); 
                    break;
                case 4:
                    printStudentReport();
                    break;
                case 5:
                    exitApplication(); 
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
    }

    public static void main(String[] args) {
        StudentManagementApplication manager = new StudentManagementApplication();
        System.out.print("Press 1 to launch menu, any other key to exit: ");
        Scanner input = new Scanner(System.in);
        String choice = input.nextLine();

        if (choice.equals("1")) {
            manager.launchMenu();
        } else {
            System.out.println("Exiting application. Goodbye!");
        }
    }
}


    

